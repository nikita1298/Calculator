import React from 'react';
import { Container, Card, Row, Col, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import NumberPad from './NumberPad';
import ResultScreen from './ResultScreen';

class Display extends React.Component {
    constructor() {
        super();

        this.state = {
            result: "",
            history: []
        }
    }



    onClick = button => {
        if (button === "=") {
            this.setState(prev => ({
                history: [...prev.history, prev.result]
            }), this.calculateOperation)
        }
        else {
            this.setState({
                result: this.state.result + button
            })
        }
    };


    calculateOperation = () => {
        var checkResult = ''
        if (this.state.result.includes('--')) {
            checkResult = this.state.result.replace('--', '+')
        }

        else {
            checkResult = this.state.result
        }
        toast(null);
        try {
            this.setState({
                result: (eval(checkResult) || "") + ""
            })
            toast("Wow success!");
        } catch (e) {
            toast("Whoops Error !");
            this.setState({
                result: "error"
            })

        }
    };

    render() {
        return (
            <Container>
                <Card style={{ width: '25rem' }}>

                    <div className="calculator-body">
                        <h1>Calculator</h1>
                        <ResultScreen result={this.state.result} sample={this.state.history} />
                        <NumberPad onClick={this.onClick} />
                    </div>
                </Card>
                <ToastContainer />
                <Link to="/faq">FAQ</Link>
            </Container>
        );
    }
}



export default Display;