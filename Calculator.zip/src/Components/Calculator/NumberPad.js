import React from 'react';
import { Row, Col, Button, ButtonGroup } from 'react-bootstrap';

class numberPad extends React.Component {

    render() {
        return (
            <div>

                <Button variant="light" size="lg" name="7" onClick={e => this.props.onClick(e.target.name)}>7</Button>
                <Button variant="light" size="lg" name="8" onClick={e => this.props.onClick(e.target.name)}>8</Button>
                <Button variant="light" size="lg" name="9" onClick={e => this.props.onClick(e.target.name)}>9</Button>
                <Button variant="warning" size="lg" name="*" onClick={e => this.props.onClick(e.target.name)}>*</Button><br />


                <Button variant="light" size="lg" name="4" onClick={e => this.props.onClick(e.target.name)}>4</Button>
                <Button variant="light" size="lg" name="5" onClick={e => this.props.onClick(e.target.name)}>5</Button>
                <Button variant="light" size="lg" name="6" onClick={e => this.props.onClick(e.target.name)}>6</Button>
                <Button variant="warning" size="lg" name="-" onClick={e => this.props.onClick(e.target.name)}>-</Button><br />

                <Button variant="light" size="lg" name="1" onClick={e => this.props.onClick(e.target.name)}>1</Button>
                <Button variant="light" size="lg" name="2" onClick={e => this.props.onClick(e.target.name)}>2</Button>
                <Button variant="light" size="lg" name="3" onClick={e => this.props.onClick(e.target.name)}>3</Button>
                <Button variant="warning" size="lg" name="+" onClick={e => this.props.onClick(e.target.name)}>+</Button><br />


                <Button variant="light" size="lg" name="." onClick={e => this.props.onClick(e.target.name)}>.</Button>
                <Button variant="light" size="lg" name="0" onClick={e => this.props.onClick(e.target.name)}>0</Button>
                <Button variant="light" size="lg" name="=" onClick={e => this.props.onClick(e.target.name)}>=</Button>
                <Button variant="warning" size="lg" name="/" onClick={e => this.props.onClick(e.target.name)}>÷</Button><br />
            </div >
        )
    }
}

export default numberPad;