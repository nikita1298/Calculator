const { FormLabel } = require("react-bootstrap")

const resultScreen = (props) => {
    let { result } = props;
    const question = (<div>
        {            props.sample.map(d => <div>{d} </div>)
        }
    </div>
    )
    return <div>
        <div style={{
            'backgroundColor': '#2c0066', 'textAlign': 'right', 'color': 'white', 'padding': '7px'
        }}>
            <label>{question}</label>
            <br />
            <label style={{ 'fontSize': '32px' }}>{result}</label>
        </div>
    </div >

}

export default resultScreen;